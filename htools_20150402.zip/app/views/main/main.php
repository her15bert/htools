<?php
use \helpers\form;
?>
<ol class="breadcrumb">
  <li class="active"><?php echo $data['title'] ?></li>
</ol>
<div class="page-header"><h1><?php echo $data['title'] ?></h1></div>