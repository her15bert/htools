<?php namespace models\money;

class Money extends \core\model {
	
    function __construct(){
            parent::__construct();
    }
    public function getSummary()
    {
        
    }
}